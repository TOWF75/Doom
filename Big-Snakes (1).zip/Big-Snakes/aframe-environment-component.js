<script src="https://unpkg.com/aframe-environment-component@1.3.3/dist/aframe-environment-component.min.js"></script>
<a-scene>
  <a-entity environment></a-entity>
  </a-scene>